# Brightness-and-Volume-controller-using-hand-gesture-recognition



It is Artificial intelligence model. Basic understanding of contolling device functions using laptop camera.

You have to run the volBrtnessControl.py file to get the output, handLmModel.py is the supporting file used by the volBrtnessControl.py to detect the hand. 
